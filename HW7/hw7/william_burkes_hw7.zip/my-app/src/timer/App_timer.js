import React from 'react';
import Game from '../tik-tok-toe'

function appTimer() {
    
      return (
        <Game/> 
      );
  }

export default appTimer;