import styled, { keyframes } from 'styled-components'

const Pin = styled.circle`
  stroke: #d00505;
  stroke-width: 0.2;  
`;

export default Pin;
