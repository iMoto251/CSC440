import React from 'react';

export function CSC414Syllabus() {
  return (
    <div>
      Syllabus
    </div>
  );
}

export function CSC414Schedule() {
  return (
    <div>
      Schedule
    </div>
  );
}

export function CSC414OtherInfo() {
  return (
    <div>
      Other Info
    </div>
  );
}