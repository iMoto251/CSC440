import React from 'react';

export function CSC440Syllabus() {
  return (
    <div>
      Syllabus
    </div>
  );
}

export function CSC440Schedule() {
  return (
    <div>
      Schedule
    </div>
  );
}

export function CSC440OtherInfo() {
  return (
    <div>
      Other Info
    </div>
  );
}