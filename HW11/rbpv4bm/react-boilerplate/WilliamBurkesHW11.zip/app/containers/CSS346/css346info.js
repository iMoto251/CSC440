import React from 'react';

export function CSS346Syllabus() {
  return (
    <div>
      Syllabus
    </div>
  );
}

export function CSS346Schedule() {
  return (
    <div>
      Schedule
    </div>
  );
}

export function CSS346OtherInfo() {
  return (
    <div>
      Other Info
    </div>
  );
}