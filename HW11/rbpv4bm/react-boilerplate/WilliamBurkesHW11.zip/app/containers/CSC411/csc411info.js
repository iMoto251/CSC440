import React from 'react';

export function CSC411Syllabus() {
  return (
    <div>
      Syllabus
    </div>
  );
}

export function CSC411Schedule() {
  return (
    <div>
      Schedule
    </div>
  );
}

export function CSC411OtherInfo() {
  return (
    <div>
      Other Info
    </div>
  );
}