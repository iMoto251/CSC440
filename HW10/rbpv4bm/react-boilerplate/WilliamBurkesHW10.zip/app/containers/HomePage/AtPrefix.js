import styled from 'styled-components';

const AtPrefix = styled.span`
  color: black;
  margin-left: 0.4em;
`;

export default AtPrefix;
